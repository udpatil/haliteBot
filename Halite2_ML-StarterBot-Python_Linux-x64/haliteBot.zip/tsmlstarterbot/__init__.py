from tsmlstarterbot.bot import Bot
